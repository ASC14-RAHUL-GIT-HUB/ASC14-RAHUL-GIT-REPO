package com.ftk.repo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnectionSingleton {

    private static Connection connection = null;

    private static final String url = "jdbc:mysql://localhost:3306/flightdb";
    private static final String user = "root";
    private static final String passwd = "mysqlroot";

    private DbConnectionSingleton() {
        // this private constructor is to not allow anyone to
        // create the instance of this class anywhere else
    }

    public static Connection getInstance() {

        if (connection == null) {
            try {

                Class.forName("com.mysql.cj.jdbc.Driver");
                // learnt this new type of getConnection parameter passing
                connection = DriverManager.getConnection(url,user, passwd);

            } catch (SQLException | ClassNotFoundException e) {
                System.out.println(e.getMessage());
            }
        }
        return connection;
    }
}

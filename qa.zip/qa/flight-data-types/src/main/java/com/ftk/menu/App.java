package com.ftk.menu;

public class App {
    public static void main(String[] args) {
        MenuUI lol = new MenuUI();
        // learnt that "driver code" is a starter or a entry point of a program.
        lol.displayMenu();
    }
}
